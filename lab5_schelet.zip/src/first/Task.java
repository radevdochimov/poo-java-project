package first;

public interface Task {

    /**
     * Executes the action characteristic of the task.
     */
    void execute();
}
